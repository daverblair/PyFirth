#!/usr/bin/env python3
name = "pyfirth"
